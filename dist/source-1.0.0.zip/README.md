# WhatsApp Privacy Shield 1.0.0

## Packages
- `dist/chrome-1.0.0.zip`, `dist/edge-1.0.0.zip`: minified Manifest V3 candidates for store review.
- `dist/firefox-1.0.0.zip`: minified Firefox candidate (Firefox 140+), requires Mozilla signing for normal distribution.
- `dist/chromium-obfuscated-local-only-1.0.0.zip`: requested JavaScript Obfuscator build for unpacked local testing ONLY. Chrome, Edge and Firefox stores prohibit obfuscation. Do not submit this artifact.
- `dist/console.js`: minified console script. `dist/console.obfuscated.js`: optional obfuscated console version.
- `dist/source-1.0.0.zip`: editable source and reproducible build kit. Keep private as appropriate; reviewers may require source.

## Maintain and rebuild
Original supplied script is unchanged in `original/privacy.js`. Edit `src/privacy.js`, never the generated files. Use Node 22+ and npm. From this folder: `npm ci`, `npm run build`, `npm test`. The lockfile pins the build dependencies. Version changes belong in package.json and build.mjs. Run the tests again after any selector or build-setting change. Obfuscation is not encryption or copy prevention.

From the website app root, `npm run generate:privacy` rebuilds all packages and synchronizes the website script. Source is outside public assets; only the obfuscated runtime is included in the website bundle and script preview. The readable maintenance source stays in src/privacy.js and is not imported into the website client bundle.

## Install locally
Chrome: unzip the chrome package, open chrome://extensions, enable Developer mode, Load unpacked, select the folder containing manifest.json.
Edge: use edge://extensions and the same Load unpacked workflow with the edge folder.
Firefox: unzip the firefox package, open about:debugging#/runtime/this-firefox, Load Temporary Add-on, select manifest.json. Temporary installations are removed when Firefox closes. Signed distribution needs a Mozilla submission.
Refresh existing WhatsApp Web tabs after installation. Enable the extension's access to web.whatsapp.com if the browser asks. Use one installation method per tab; running both console and extension versions concurrently is not supported.

## Behavior and implementation differences
Runs only on https://web.whatsapp.com and injects local styles/UI. Starts ON at medium blur on every page load. Hover/focus reveals matching rows. Settings exist only in memory. The privacy shield is mounted after data-testid=drawer-title-body, following the supplied updated source; a top-right fallback is added if it is absent. This version is not the earlier draggable prototype. × closes settings; OFF clears blur. Disable/remove the extension and refresh to remove its controls. Console users refresh to remove the tool.

Hardening: static SVG uses DOM creation instead of innerHTML; observer work is batched per animation frame; observer and resize/scroll listeners are cleaned up on reinjection; popup follows page scroll; a domain guard prevents running elsewhere; icon is green when privacy is ON and gray when OFF.

## Review and limitations
This is visual privacy, not encryption, authorization, or guaranteed screen-share protection. Content can appear before the script starts, when hovered/focused, or where selectors do not match. Search, group-info, notifications, media and changed WhatsApp markup may remain visible. No hidden-data access or internal WhatsApp APIs. Not affiliated with WhatsApp or Meta.

Before public release, manually test an authorized WhatsApp account in Chrome, Edge and Firefox, light/dark themes, mouse and keyboard reveal, header remount, login/logout, refresh, disable/uninstall, and narrow windows. Verify both console and installed extension behavior separately. Synthetic tests do not verify current live WhatsApp compatibility. No store upload, signing or website deployment has been performed.

Store references:
- https://developer.chrome.com/docs/webstore/program-policies/code-readability
- https://extensionworkshop.com/documentation/publish/source-code-submission/
- https://learn.microsoft.com/legal/microsoft-edge/extensions/developer-policies
- https://extensionworkshop.com/documentation/develop/firefox-builtin-data-consent/

Store listing draft: “Blur matching WhatsApp Web conversations. Reveal rows on hover or keyboard focus. Use a compact privacy shield to toggle privacy and choose blur strength. Works locally with no analytics, account, or data collection.” Provide PRIVACY.md at a public URL when submitting. Reviewers must test with their own authorized WhatsApp account; never supply personal credentials.

## Verification recorded for this draft
16 Node synthetic-DOM and manifest tests passed against editable source plus Chrome, Edge, Firefox and obfuscated generated scripts. Targeted website ESLint and production Next.js build passed; `/tools/whatsapp-privacy-shield` was included in the generated routes. Original source compared byte-for-byte with the supplied file. These checks do not substitute for installed-extension testing or store review; live browser/WhatsApp compatibility is not yet verified.

Scroll-stability adjustment: hover/focus uses blur(0px), preserving the filter containing block instead of switching to none. Toolbar focus uses preventScroll. No scrollTop changes or forced scrolling are introduced. Reopening already-read chats requires live regression testing; the reported intermittent jump has not been reproduced in the synthetic fixture.

Chat modes: Messages reveals only a hovered/focused message row. Entire chat (default) reveals all matching message rows when the open #main conversation is hovered/focused. Sidebar rows always reveal independently. The header and composer are not blurred. This groups the existing row blur rather than filtering the virtualized conversation container, to avoid changing its containing-block behavior. Unmatched content remains outside coverage. Modes reset on reload.
